"use client"

import { createContext, useContext, useState, useEffect } from "react"
import { createTheme, type ThemeColor } from "../styles/theme"

type Transaction = {
  id: string
  accountId: string
  type: "credit" | "debit"
  amount: number
  description: string
  date: string
  category: string
}

type Account = {
  id: string
  user_id: string
  name: string
  balance: number
  accountNumber: string
  showOnHomeScreen: boolean
  cardDetails: {
    cardNumber: string
    expiryDate: string
    cvv: string
  }
}

type User = {
  id: string
  username: string
  email: string
  name: string
  phoneNumber: string
  address: string
}

type AdminUser = {
  id: string
  username: string
  email: string
  name: string
}

type AccountContextType = {
  user: User | null
  accounts: Account[]
  transactions: Transaction[]
  addAccount: (name: string) => void
  addTransaction: (transaction: Omit<Transaction, "id">) => void
  addMoneyToAccount: (accountId: string, amount: number) => void
  toggleAccountOnHomeScreen: (accountId: string) => void
  themeColor: ThemeColor
  isDarkMode: boolean
  setThemeColor: (color: ThemeColor) => void
  toggleDarkMode: () => void
  theme: ReturnType<typeof createTheme>
  signUp: (email: string, password: string, name: string) => void
  login: (email: string, password: string) => void
  logout: () => void
  adminUser: AdminUser | null
  isAdmin: boolean
  isDemoUser: boolean
  loginAsAdmin: (username: string) => void
  loginAsDemo: () => void
  coolThemeEnabled: boolean
  setCoolThemeEnabled: (enabled: boolean) => void
  selectedHomeAccountId: string | null
  setSelectedHomeAccountId: (accountId: string | null) => void
  secretPageEnabled: boolean
  setSecretPageEnabled: (enabled: boolean) => void
  changeDemoAccountName: (newName: string) => void
  demoAccountName: string
  users: User[]
  updateUserDetails: (userId: string, details: Partial<User>) => void
  updateAccountDetails: (accountId: string, details: Partial<Account>) => void
  updateCardDetails: (accountId: string, cardDetails: Account["cardDetails"]) => void
  bankName: string
  setBankName: (name: string) => void
}

const AccountContext = createContext<AccountContextType | undefined>(undefined)

export const useAccounts = () => {
  const context = useContext(AccountContext)
  if (!context) {
    throw new Error("useAccounts must be used within an AccountProvider")
  }
  return context
}

export const AccountProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    if (typeof window !== "undefined") {
      const savedUser = localStorage.getItem("user")
      return savedUser ? JSON.parse(savedUser) : null
    }
    return null
  })
  const [accounts, setAccounts] = useState<Account[]>(() => {
    if (typeof window !== "undefined") {
      const savedAccounts = localStorage.getItem("accounts")
      return savedAccounts ? JSON.parse(savedAccounts) : []
    }
    return []
  })
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    if (typeof window !== "undefined") {
      const savedTransactions = localStorage.getItem("transactions")
      return savedTransactions ? JSON.parse(savedTransactions) : []
    }
    return []
  })
  const [themeColor, setThemeColor] = useState<ThemeColor>(() => {
    if (typeof window !== "undefined") {
      return (localStorage.getItem("themeColor") as ThemeColor) || "slate"
    }
    return "slate"
  })
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const savedMode = localStorage.getItem("isDarkMode")
      return savedMode === null ? true : savedMode === "true"
    }
    return true
  })

  const [adminUser, setAdminUser] = useState<AdminUser | null>(() => {
    if (typeof window !== "undefined") {
      const savedAdminUser = localStorage.getItem("adminUser")
      return savedAdminUser ? JSON.parse(savedAdminUser) : null
    }
    return null
  })
  const [isAdmin, setIsAdmin] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("isAdmin") === "true"
    }
    return false
  })
  const [isDemoUser, setIsDemoUser] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("isDemoUser") === "true"
    }
    return false
  })
  const [coolThemeEnabled, setCoolThemeEnabled] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("coolThemeEnabled") === "true"
    }
    return false
  })
  const [selectedHomeAccountId, setSelectedHomeAccountId] = useState<string | null>(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("selectedHomeAccountId")
    }
    return null
  })
  const [secretPageEnabled, setSecretPageEnabled] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("secretPageEnabled") === "true"
    }
    return false
  })
  const [demoAccountName, setDemoAccountName] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("demoAccountName") || "Demo User"
    }
    return "Demo User"
  })
  const [users, setUsers] = useState<User[]>(() => {
    if (typeof window !== "undefined") {
      const savedUsers = localStorage.getItem("users")
      return savedUsers ? JSON.parse(savedUsers) : []
    }
    return []
  })
  const [bankName, setBankName] = useState(() => {
    if (typeof window !== "undefined") {
      return localStorage.getItem("bankName") || "Central Livingston Banking"
    }
    return "Central Livingston Banking"
  })

  const theme = createTheme(themeColor, isDarkMode)

  const addAccount = (name: string) => {
    const newAccount: Account = {
      id: Date.now().toString(),
      user_id: user?.id || "",
      name,
      balance: 0,
      accountNumber: Math.floor(Math.random() * 10000)
        .toString()
        .padStart(4, "0"),
      showOnHomeScreen: true,
      cardDetails: {
        cardNumber: "",
        expiryDate: "",
        cvv: "",
      },
    }
    setAccounts([...accounts, newAccount])
  }

  const addMoneyToAccount = (accountId: string, amount: number) => {
    setAccounts(
      accounts.map((account) =>
        account.id === accountId ? { ...account, balance: account.balance + amount } : account,
      ),
    )
  }

  const addTransaction = (transaction: Omit<Transaction, "id">) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
    }
    setTransactions([newTransaction, ...transactions])

    // Update account balance
    const account = accounts.find((a) => a.id === transaction.accountId)
    if (account) {
      const newBalance =
        transaction.type === "credit" ? account.balance + transaction.amount : account.balance - transaction.amount
      setAccounts(accounts.map((a) => (a.id === account.id ? { ...a, balance: newBalance } : a)))
    }
  }

  const toggleAccountOnHomeScreen = (accountId: string) => {
    setAccounts(
      accounts.map((account) =>
        account.id === accountId ? { ...account, showOnHomeScreen: !account.showOnHomeScreen } : account,
      ),
    )
  }

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode)

  const signUp = (email: string, password: string, name: string) => {
    const newUser: User = {
      id: Date.now().toString(),
      email,
      name,
      username: email,
      phoneNumber: "",
      address: "",
    }
    setUser(newUser)
    // In a real app, you'd hash the password. For this demo, we'll store it as-is (not recommended for production!)
    localStorage.setItem("userPassword", password)
  }

  const loginAsAdmin = (username: string) => {
    const adminData: AdminUser = {
      id: "admin",
      username,
      email: "admin@example.com",
      name: "Admin User",
    }
    setAdminUser(adminData)
    setIsAdmin(true)
    setIsDemoUser(false)
  }

  const loginAsDemo = () => {
    const demoUser: User = {
      id: "demo",
      username: "demo",
      email: "demo@example.com",
      name: demoAccountName,
      phoneNumber: "1234567890",
      address: "123 Demo St, Demo City, DC 12345",
    }
    setUser(demoUser)
    setIsAdmin(false)
    setIsDemoUser(true)
  }

  const login = (email: string, password: string) => {
    const storedPassword = localStorage.getItem("userPassword")
    if (user && user.email === email && storedPassword === password) {
      // Login successful
      setUser(user)
    } else {
      throw new Error("Invalid email or password")
    }
  }

  const logout = () => {
    setUser(null)
  }

  const changeDemoAccountName = (newName: string) => {
    if (isDemoUser) {
      setDemoAccountName(newName)
    }
  }

  const updateUserDetails = (userId: string, details: Partial<User>) => {
    setUsers(users.map((u) => (u.id === userId ? { ...u, ...details } : u)))
    if (user && user.id === userId) {
      setUser({ ...user, ...details })
    }
  }

  const updateAccountDetails = (accountId: string, details: Partial<Account>) => {
    setAccounts(accounts.map((a) => (a.id === accountId ? { ...a, ...details } : a)))
  }

  const updateCardDetails = (accountId: string, cardDetails: Account["cardDetails"]) => {
    setAccounts(accounts.map((a) => (a.id === accountId ? { ...a, cardDetails } : a)))
  }

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("user", JSON.stringify(user))
      localStorage.setItem("accounts", JSON.stringify(accounts))
      localStorage.setItem("transactions", JSON.stringify(transactions))
      localStorage.setItem("themeColor", themeColor)
      localStorage.setItem("isDarkMode", JSON.stringify(isDarkMode))
      localStorage.setItem("adminUser", JSON.stringify(adminUser))
      localStorage.setItem("isAdmin", JSON.stringify(isAdmin))
      localStorage.setItem("isDemoUser", JSON.stringify(isDemoUser))
      localStorage.setItem("coolThemeEnabled", JSON.stringify(coolThemeEnabled))
      localStorage.setItem("selectedHomeAccountId", selectedHomeAccountId || "")
      localStorage.setItem("secretPageEnabled", JSON.stringify(secretPageEnabled))
      localStorage.setItem("demoAccountName", demoAccountName)
      localStorage.setItem("users", JSON.stringify(users))
      localStorage.setItem("bankName", bankName)
    }
  }, [
    user,
    accounts,
    transactions,
    themeColor,
    isDarkMode,
    adminUser,
    isAdmin,
    isDemoUser,
    coolThemeEnabled,
    selectedHomeAccountId,
    secretPageEnabled,
    demoAccountName,
    users,
    bankName,
  ])

  return (
    <AccountContext.Provider
      value={{
        user,
        accounts,
        transactions,
        addAccount,
        addTransaction,
        addMoneyToAccount,
        toggleAccountOnHomeScreen,
        themeColor,
        isDarkMode,
        setThemeColor,
        toggleDarkMode,
        theme,
        signUp,
        login,
        logout,
        adminUser,
        isAdmin,
        isDemoUser,
        loginAsAdmin,
        loginAsDemo,
        coolThemeEnabled,
        setCoolThemeEnabled,
        selectedHomeAccountId,
        setSelectedHomeAccountId,
        secretPageEnabled,
        setSecretPageEnabled,
        changeDemoAccountName,
        demoAccountName,
        users,
        updateUserDetails,
        updateAccountDetails,
        updateCardDetails,
        bankName,
        setBankName,
      }}
    >
      {children}
    </AccountContext.Provider>
  )
}

