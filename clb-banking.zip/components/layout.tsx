"use client"

import { useAccounts } from "../contexts/AccountContext"
import Header from "./header"
import BottomNav from "./bottom-nav"
import AccountMenu from "./account-menu"

export default function Layout({ children }: { children: React.ReactNode }) {
  const { user, theme } = useAccounts()

  return (
    <div
      className="flex flex-col min-h-screen"
      style={{
        backgroundColor: theme.colors.background,
        color: theme.colors.text,
      }}
    >
      <Header />
      <main className="flex-1 overflow-y-auto pb-20 px-4 py-6 max-w-3xl mx-auto w-full">
        <div className="flex justify-end mb-4">
          <AccountMenu />
        </div>
        {children}
      </main>
      {user && <BottomNav />}
    </div>
  )
}

