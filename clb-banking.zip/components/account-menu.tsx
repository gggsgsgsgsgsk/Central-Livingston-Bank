"use client"

import { useState } from "react"
import Link from "next/link"
import { useAccounts } from "../contexts/AccountContext"
import { Button } from "@/components/ui/button"
import { User, LogOut, Settings } from "lucide-react"

export default function AccountMenu() {
  const [isOpen, setIsOpen] = useState(false)
  const { user, logout, theme } = useAccounts()

  if (!user) return null

  return (
    <div className="relative">
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-2 rounded-full"
        style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
      >
        <User size={20} />
        <span>{user.name}</span>
      </Button>
      {isOpen && (
        <div
          className="absolute right-0 mt-2 w-48 rounded-xl shadow-lg py-1 ring-1 ring-black ring-opacity-5"
          style={{ backgroundColor: theme.colors.surface }}
        >
          <Link href="/settings">
            <Button
              className="flex items-center w-full px-4 py-2 text-sm rounded-none"
              style={{ color: theme.colors.text }}
            >
              <Settings size={20} className="mr-2" />
              Settings
            </Button>
          </Link>
          <Button
            onClick={logout}
            className="flex items-center w-full px-4 py-2 text-sm rounded-none"
            style={{ color: theme.colors.text }}
          >
            <LogOut size={20} className="mr-2" />
            Log Out
          </Button>
        </div>
      )}
    </div>
  )
}

