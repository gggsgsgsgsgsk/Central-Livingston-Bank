"use client"

import { Home, CreditCard, List, Settings, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useAccounts } from "../contexts/AccountContext"

const regularNavItems = [
  { icon: Home, label: "Home", href: "/dashboard" },
  { icon: CreditCard, label: "Accounts", href: "/accounts" },
  { icon: List, label: "Transactions", href: "/transactions" },
  { icon: User, label: "Account", href: "/account-settings" },
  { icon: Settings, label: "Settings", href: "/settings" },
]

const adminNavItems = [
  { icon: Home, label: "Dashboard", href: "/admin-dashboard" },
  { icon: CreditCard, label: "Accounts", href: "/admin/accounts" },
  { icon: List, label: "Transactions", href: "/admin/transactions" },
  { icon: Settings, label: "Settings", href: "/admin/settings" },
]

export default function BottomNav() {
  const pathname = usePathname()
  const { theme, isAdmin, isDemoUser } = useAccounts()

  const navItemsToUse = isAdmin ? adminNavItems : regularNavItems

  if (isAdmin && pathname === "/") return null

  return (
    <nav
      style={{ backgroundColor: theme.colors.surface }}
      className="fixed bottom-0 left-0 right-0 shadow-lg rounded-t-xl"
    >
      <ul className="flex justify-around">
        {navItemsToUse.map(({ icon: Icon, label, href }) => (
          <li key={href}>
            <Link
              href={href}
              style={{ color: pathname === href ? theme.colors.primary : theme.colors.textSecondary }}
              className="flex flex-col items-center p-2"
            >
              <Icon className="w-6 h-6" />
              <span className="text-xs mt-1">{label}</span>
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  )
}

