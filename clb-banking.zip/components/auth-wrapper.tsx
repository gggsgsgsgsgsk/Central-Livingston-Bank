"use client"

import { useEffect } from "react"
import { useRouter, usePathname } from "next/navigation"
import { useAccounts } from "../contexts/AccountContext"

const publicPaths = ["/", "/login", "/signup"]
const adminPaths = ["/admin-dashboard", "/admin/create-account", "/admin/transactions"]
const secretPagePath = "/secret-page"

export default function AuthWrapper({ children }: { children: React.ReactNode }) {
  const { user, isAdmin, isDemoUser, secretPageEnabled } = useAccounts()
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (isAdmin) {
      if (!adminPaths.includes(pathname) && pathname !== "/") {
        router.push("/admin-dashboard")
      }
    } else if (user || isDemoUser) {
      if (publicPaths.includes(pathname)) {
        router.push("/dashboard")
      }
    } else if (!publicPaths.includes(pathname) && pathname !== secretPagePath) {
      router.push("/")
    }

    if (pathname === secretPagePath && !secretPageEnabled) {
      router.push("/settings")
    }
  }, [user, isAdmin, isDemoUser, secretPageEnabled, pathname, router])

  return <>{children}</>
}

