"use client"

import { Bell } from "lucide-react"
import { useAccounts } from "../contexts/AccountContext"
import { usePathname } from "next/navigation"

export default function Header() {
  const { theme, bankName } = useAccounts()
  const pathname = usePathname()
  const isLandingPage = pathname === "/"

  return (
    <header
      style={{ backgroundColor: theme.colors.surface }}
      className="p-4 flex justify-between items-center shadow-sm"
    >
      <h1 className="text-xl font-bold" style={{ color: theme.colors.primary }}>
        {bankName}
      </h1>
      {!isLandingPage && <Bell className="w-6 h-6" style={{ color: theme.colors.text }} />}
    </header>
  )
}

