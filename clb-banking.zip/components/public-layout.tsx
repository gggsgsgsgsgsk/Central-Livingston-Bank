"use client"

import { useAccounts } from "../contexts/AccountContext"
import { usePathname } from "next/navigation"

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  const { theme } = useAccounts()
  const pathname = usePathname()

  //const isLandingPage = pathname === "/"

  return (
    <div
      className="flex flex-col min-h-screen"
      style={{
        backgroundColor: theme.colors.background,
        color: theme.colors.text,
      }}
    >
      {/* Header is now rendered in individual pages */}
      <main className={`flex-1 overflow-y-auto`}>{children}</main>
    </div>
  )
}

