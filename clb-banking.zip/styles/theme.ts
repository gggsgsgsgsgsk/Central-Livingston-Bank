export type ThemeColor = "purple" | "blue" | "green" | "orange" | "slate" | "teal" | "indigo" | "rose"

export const themeColors: Record<
  ThemeColor,
  {
    primary: string
    primaryLight: string
    secondary: string
    accent: string
  }
> = {
  purple: {
    primary: "#4A148C",
    primaryLight: "#7E57C2",
    secondary: "#FF4081",
    accent: "#B39DDB",
  },
  blue: {
    primary: "#0D47A1",
    primaryLight: "#42A5F5",
    secondary: "#FF6E40",
    accent: "#90CAF9",
  },
  green: {
    primary: "#1B5E20",
    primaryLight: "#66BB6A",
    secondary: "#FF7043",
    accent: "#A5D6A7",
  },
  orange: {
    primary: "#E65100",
    primaryLight: "#FFA726",
    secondary: "#536DFE",
    accent: "#FFCC80",
  },
  slate: {
    primary: "#37474F",
    primaryLight: "#78909C",
    secondary: "#FF8A65",
    accent: "#B0BEC5",
  },
  teal: {
    primary: "#00695C",
    primaryLight: "#4DB6AC",
    secondary: "#FF5252",
    accent: "#80CBC4",
  },
  indigo: {
    primary: "#1A237E",
    primaryLight: "#5C6BC0",
    secondary: "#FF4081",
    accent: "#9FA8DA",
  },
  rose: {
    primary: "#880E4F",
    primaryLight: "#EC407A",
    secondary: "#40C4FF",
    accent: "#F48FB1",
  },
}

export const createTheme = (color: ThemeColor, isDark = true) => ({
  colors: {
    ...themeColors[color],
    background: isDark ? "#121212" : "#F5F5F5",
    surface: isDark ? "#1E1E1E" : "#FFFFFF",
    surfaceLight: isDark ? "#2C2C2C" : "#F0F0F0",
    surfaceHover: isDark ? "#383838" : "#E8E8E8",
    error: isDark ? "#CF6679" : "#B00020",
    text: isDark ? "#FFFFFF" : "#000000",
    textSecondary: isDark ? "#B0B0B0" : "#505050",
    textTertiary: isDark ? "#808080" : "#707070",
  },
  borderRadius: "12px",
})

export const inputStyles = `
  focus:ring-2 focus:ring-opacity-50
  rounded-lg py-2 px-4 block w-full appearance-none leading-normal
  transition duration-150 ease-in-out
  bg-opacity-10 hover:bg-opacity-20
`

export const cardStyles = `
  rounded-xl overflow-hidden
  transition-all duration-300 ease-in-out
  hover:bg-opacity-80
`

export const buttonStyles = `
  py-2 px-4 rounded-lg font-semibold text-white
  transition duration-300 ease-in-out
  focus:outline-none focus:ring-2 focus:ring-opacity-50
`

export const selectStyles = `
  relative w-full
  after:content-['▼'] after:absolute after:right-3 after:top-1/2 after:-translate-y-1/2
  after:text-sm after:pointer-events-none
`

