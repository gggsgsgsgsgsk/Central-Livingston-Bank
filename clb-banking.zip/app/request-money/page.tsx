"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAccounts } from "../../contexts/AccountContext"
import { toast } from "@/components/ui/use-toast"
import { cardStyles, inputStyles, buttonStyles } from "../../styles/theme"

export default function RequestMoney() {
  const [amount, setAmount] = useState("")
  const [sender, setSender] = useState("")
  const [selectedAccountId, setSelectedAccountId] = useState("")
  const { accounts, theme } = useAccounts()
  const router = useRouter()

  const handleRequestMoney = (e: React.FormEvent) => {
    e.preventDefault()
    const parsedAmount = Number.parseFloat(amount)
    if (isNaN(parsedAmount) || parsedAmount <= 0 || !selectedAccountId || !sender) {
      toast({
        title: "Invalid input",
        description: "Please fill in all fields with valid values.",
        variant: "destructive",
      })
      return
    }
    // In a real app, this would send a request to the specified person
    // For now, we'll just show a success message
    toast({
      title: "Money requested",
      description: `Request for £${parsedAmount.toFixed(2)} has been sent to ${sender}.`,
    })
    router.push("/")
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Request Money
        </h2>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.secondary }}>Request Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleRequestMoney} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={inputStyles}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account to receive money" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="text"
                placeholder="Sender"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="number"
                placeholder="Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                step="0.01"
                min="0"
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={buttonStyles}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Request Money
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

