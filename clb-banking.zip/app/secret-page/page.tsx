"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { toast } from "@/components/ui/use-toast"
import { cardStyles, inputStyles, buttonStyles, selectStyles } from "../../styles/theme"

const transactionCategories = ["Food & Drink", "Shopping", "Transport", "Bills", "Entertainment", "Cash", "Other"]

export default function SecretPage() {
  const {
    accounts,
    addAccount,
    addFakeMoney,
    addTransaction,
    theme,
    isDemoUser,
    changeDemoAccountName,
    demoAccountName,
    bankName,
    setBankName,
  } = useAccounts()
  const router = useRouter()

  const [newAccountName, setNewAccountName] = useState("")
  const [fakeMoneyAmount, setFakeMoneyAmount] = useState("")
  const [selectedAccountId, setSelectedAccountId] = useState("")
  const [transactionAmount, setTransactionAmount] = useState("")
  const [transactionType, setTransactionType] = useState<"credit" | "debit">("credit")
  const [transactionDescription, setTransactionDescription] = useState("")
  const [transactionCategory, setTransactionCategory] = useState("")
  const [demoName, setDemoName] = useState(demoAccountName)
  const [newBankName, setNewBankName] = useState(bankName)

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault()
    if (newAccountName.trim()) {
      addAccount(newAccountName.trim())
      toast({
        title: "Account created",
        description: `New account "${newAccountName}" has been created successfully.`,
      })
      setNewAccountName("")
    }
  }

  const handleAddFakeMoney = (e: React.FormEvent) => {
    e.preventDefault()
    const amount = Number.parseFloat(fakeMoneyAmount)
    if (isNaN(amount) || amount <= 0 || !selectedAccountId) {
      toast({
        title: "Invalid input",
        description: "Please enter a valid positive number and select an account.",
        variant: "destructive",
      })
      return
    }
    addFakeMoney(selectedAccountId, amount)
    toast({
      title: "Fake money added",
      description: `£${amount.toFixed(2)} has been added to the selected account.`,
    })
    setFakeMoneyAmount("")
    setSelectedAccountId("")
  }

  const handleCreateTransaction = (e: React.FormEvent) => {
    e.preventDefault()
    const amount = Number.parseFloat(transactionAmount)
    if (isNaN(amount) || amount <= 0 || !selectedAccountId || !transactionDescription || !transactionCategory) {
      toast({
        title: "Invalid input",
        description: "Please fill in all fields with valid values.",
        variant: "destructive",
      })
      return
    }
    addTransaction({
      accountId: selectedAccountId,
      type: transactionType,
      amount,
      description: transactionDescription,
      date: new Date().toISOString(),
      category: transactionCategory,
    })
    toast({
      title: "Transaction created",
      description: `${transactionType === "credit" ? "Received" : "Spent"} £${amount.toFixed(2)} for ${transactionDescription}`,
    })
    setTransactionAmount("")
    setTransactionDescription("")
    setTransactionCategory("")
  }

  const handleChangeDemoName = (e: React.FormEvent) => {
    e.preventDefault()
    if (isDemoUser && demoName.trim()) {
      changeDemoAccountName(demoName.trim())
      toast({
        title: "Name changed",
        description: `Your account name has been changed to "${demoName}".`,
      })
    }
  }

  const generateRandomTransactions = () => {
    if (!selectedAccountId) {
      toast({
        title: "Error",
        description: "Please select an account first.",
        variant: "destructive",
      })
      return
    }

    const numTransactions = Math.floor(Math.random() * 5) + 1 // Generate 1-5 transactions
    for (let i = 0; i < numTransactions; i++) {
      const type = Math.random() > 0.5 ? "credit" : "debit"
      const amount = Number.parseFloat((Math.random() * 100 + 1).toFixed(2))
      const category = transactionCategories[Math.floor(Math.random() * transactionCategories.length)]
      const description = `Random ${type === "credit" ? "income" : "expense"}`

      addTransaction({
        accountId: selectedAccountId,
        type,
        amount,
        description,
        date: new Date().toISOString(),
        category,
      })
    }

    toast({
      title: "Random transactions generated",
      description: `${numTransactions} random transactions have been added to the selected account.`,
    })
  }

  const simulateMarketFluctuation = () => {
    accounts.forEach((account) => {
      const fluctuation = Number.parseFloat((Math.random() * 20 - 10).toFixed(2)) // -10% to +10%
      const changeAmount = (account.balance * fluctuation) / 100
      addFakeMoney(account.id, changeAmount)
    })

    toast({
      title: "Market fluctuation simulated",
      description: "All account balances have been adjusted to simulate market changes.",
    })
  }

  const createVirtualCreditCard = () => {
    if (!selectedAccountId) {
      toast({
        title: "Error",
        description: "Please select an account first.",
        variant: "destructive",
      })
      return
    }

    const cardNumber = Math.floor(Math.random() * 9000000000000000 + 1000000000000000).toString()
    const expiryMonth = Math.floor(Math.random() * 12 + 1)
      .toString()
      .padStart(2, "0")
    const expiryYear = (new Date().getFullYear() + Math.floor(Math.random() * 5 + 1)).toString().slice(-2)
    const cvv = Math.floor(Math.random() * 900 + 100).toString()

    toast({
      title: "Virtual Credit Card Created",
      description: `Card Number: ${cardNumber}, Expiry: ${expiryMonth}/${expiryYear}, CVV: ${cvv}`,
    })
  }

  const handleChangeBankName = (e: React.FormEvent) => {
    e.preventDefault()
    if (newBankName.trim()) {
      setBankName(newBankName.trim())
      toast({
        title: "Bank name changed",
        description: `The bank name has been changed to "${newBankName}".`,
      })
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Secret Management Page
        </h2>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Change Bank Name</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleChangeBankName} className="space-y-4">
              <Input
                type="text"
                placeholder="New Bank Name"
                value={newBankName}
                onChange={(e) => setNewBankName(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Change Bank Name
              </Button>
            </form>
          </CardContent>
        </Card>

        {isDemoUser && (
          <Card
            className={cardStyles}
            style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
          >
            <CardHeader>
              <CardTitle style={{ color: theme.colors.text }}>Change Demo Account Name</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleChangeDemoName} className="space-y-4">
                <Input
                  type="text"
                  placeholder="New Account Name"
                  value={demoName}
                  onChange={(e) => setDemoName(e.target.value)}
                  className={`${inputStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                />
                <Button
                  type="submit"
                  className={`${buttonStyles} w-full rounded-lg`}
                  style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
                >
                  Change Name
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Create New Account</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateAccount} className="space-y-4">
              <Input
                type="text"
                placeholder="Account Name"
                value={newAccountName}
                onChange={(e) => setNewAccountName(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Create Account
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Add Fake Money</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddFakeMoney} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Amount"
                value={fakeMoneyAmount}
                onChange={(e) => setFakeMoneyAmount(e.target.value)}
                step="0.01"
                min="0"
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Add Fake Money
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Create Transaction</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateTransaction} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                onValueChange={(value) => setTransactionType(value as "credit" | "debit")}
                value={transactionType}
              >
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Transaction type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="credit">Credit (Receive)</SelectItem>
                  <SelectItem value="debit">Debit (Spend)</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Amount"
                value={transactionAmount}
                onChange={(e) => setTransactionAmount(e.target.value)}
                step="0.01"
                min="0"
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="text"
                placeholder="Description"
                value={transactionDescription}
                onChange={(e) => setTransactionDescription(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Select onValueChange={setTransactionCategory} value={transactionCategory}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {transactionCategories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Create Transaction
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Advanced Options</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button
              onClick={generateRandomTransactions}
              className={`${buttonStyles} w-full rounded-lg`}
              style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
            >
              Generate Random Transactions
            </Button>
            <Button
              onClick={simulateMarketFluctuation}
              className={`${buttonStyles} w-full rounded-lg`}
              style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
            >
              Simulate Market Fluctuation
            </Button>
            <Button
              onClick={createVirtualCreditCard}
              className={`${buttonStyles} w-full rounded-lg`}
              style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
            >
              Create Virtual Credit Card
            </Button>
          </CardContent>
        </Card>

        <Button
          onClick={() => router.push("/settings")}
          className={`${buttonStyles} w-full rounded-lg`}
          style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
        >
          Back to Settings
        </Button>
      </div>
    </Layout>
  )
}

