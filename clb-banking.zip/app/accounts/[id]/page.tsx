"use client"

import { useParams } from "next/navigation"
import Layout from "../../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useAccounts } from "../../../contexts/AccountContext"
import { cardStyles } from "../../../styles/theme"
import { ArrowUpRight, ArrowDownLeft } from "lucide-react"

export default function AccountTransactions() {
  const { id } = useParams()
  const { accounts, transactions, theme } = useAccounts()

  const account = accounts.find((a) => a.id === id)
  const accountTransactions = transactions.filter((t) => t.accountId === id)

  if (!account) {
    return (
      <Layout>
        <div>Account not found</div>
      </Layout>
    )
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          {account.name}
        </h2>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.secondary }}>Account Balance</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold" style={{ color: theme.colors.text }}>
              £{account.balance.toFixed(2)}
            </p>
            <p className="text-sm" style={{ color: theme.colors.textSecondary }}>
              Account number: ****{account.accountNumber}
            </p>
          </CardContent>
        </Card>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.secondary }}>Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            {accountTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="flex justify-between items-center mb-4 pb-4 border-b border-gray-200 last:border-b-0"
              >
                <div className="flex items-center">
                  {transaction.type === "credit" ? (
                    <ArrowDownLeft className="w-6 h-6 mr-3" style={{ color: theme.colors.secondary }} />
                  ) : (
                    <ArrowUpRight className="w-6 h-6 mr-3" style={{ color: theme.colors.error }} />
                  )}
                  <div>
                    <p className="font-medium" style={{ color: theme.colors.text }}>
                      {transaction.description}
                    </p>
                    <p className="text-sm" style={{ color: theme.colors.textSecondary }}>
                      {new Date(transaction.date).toLocaleDateString()} - {transaction.category}
                    </p>
                  </div>
                </div>
                <p
                  className="font-bold"
                  style={{ color: transaction.type === "credit" ? theme.colors.secondary : theme.colors.error }}
                >
                  {transaction.type === "credit" ? "+" : "-"}£{transaction.amount.toFixed(2)}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

