"use client"

import Layout from "../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { useAccounts } from "../../contexts/AccountContext"
import { cardStyles } from "../../styles/theme"
import { ArrowUpRight, ArrowDownLeft } from "lucide-react"
import Link from "next/link"

export default function Accounts() {
  const { accounts, toggleAccountOnHomeScreen, transactions, theme, selectedHomeAccountId, setSelectedHomeAccountId } =
    useAccounts()

  const handleHomeScreenToggle = (accountId: string) => {
    if (selectedHomeAccountId === accountId) {
      setSelectedHomeAccountId(null)
    } else {
      setSelectedHomeAccountId(accountId)
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Your Accounts
        </h2>
        {accounts.map((account) => (
          <Card
            key={account.id}
            className={cardStyles}
            style={{ backgroundColor: theme.colors.surface, boxShadow: "none" }}
          >
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle style={{ color: theme.colors.text }}>{account.name}</CardTitle>
              <div className="flex items-center space-x-2">
                <span className="text-sm" style={{ color: theme.colors.textSecondary }}>
                  {selectedHomeAccountId === account.id ? "On Home" : "Off Home"}
                </span>
                <Switch
                  checked={selectedHomeAccountId === account.id}
                  onCheckedChange={() => handleHomeScreenToggle(account.id)}
                />
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold mb-2" style={{ color: theme.colors.primary }}>
                £{account.balance.toFixed(2)}
              </p>
              <p className="text-sm mb-4" style={{ color: theme.colors.textSecondary }}>
                Account number: {account.accountNumber}
              </p>
              <h4 className="font-semibold mb-2" style={{ color: theme.colors.text }}>
                Recent Transactions
              </h4>
              {transactions
                .filter((t) => t.accountId === account.id)
                .slice(0, 5)
                .map((transaction) => (
                  <div
                    key={transaction.id}
                    className="flex justify-between items-center mb-2 p-2 rounded-lg"
                    style={{ backgroundColor: theme.colors.surfaceLight }}
                  >
                    <div className="flex items-center">
                      {transaction.type === "credit" ? (
                        <ArrowDownLeft className="w-4 h-4 mr-2" style={{ color: theme.colors.secondary }} />
                      ) : (
                        <ArrowUpRight className="w-4 h-4 mr-2" style={{ color: theme.colors.error }} />
                      )}
                      <span style={{ color: theme.colors.text }}>{transaction.description}</span>
                    </div>
                    <span
                      className="font-semibold"
                      style={{ color: transaction.type === "credit" ? theme.colors.secondary : theme.colors.error }}
                    >
                      {transaction.type === "credit" ? "+" : "-"}£{transaction.amount.toFixed(2)}
                    </span>
                  </div>
                ))}
              <Link
                href={`/accounts/${account.id}`}
                className="text-sm font-semibold mt-2 inline-block"
                style={{ color: theme.colors.primary }}
              >
                View all transactions
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  )
}

