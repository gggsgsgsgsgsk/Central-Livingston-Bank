"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import PublicLayout from "../../components/public-layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { cardStyles, inputStyles, buttonStyles } from "../../styles/theme"
import { toast } from "@/components/ui/use-toast"
import Link from "next/link"

export default function Login() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { login, theme } = useAccounts()
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      login(email, password)
      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Login Error",
        description: "Invalid email or password.",
        variant: "destructive",
      })
    }
  }

  return (
    <PublicLayout>
      <div className="flex justify-center items-center min-h-screen">
        <Card className={`${cardStyles} w-full max-w-md`} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle className="text-2xl font-bold" style={{ color: theme.colors.primary }}>
              Log In
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Log In
              </Button>
            </form>
            <p className="mt-4 text-center" style={{ color: theme.colors.text }}>
              Don't have an account?{" "}
              <Link href="/signup" className="font-bold" style={{ color: theme.colors.primary }}>
                Sign Up
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </PublicLayout>
  )
}

