"use client"

import { useAccounts } from "../contexts/AccountContext"
import PublicLayout from "../components/public-layout"
import Layout from "../components/layout"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Header from "../components/header"
import { Shield, Smartphone, TrendingUp, Users, Banknote, Clock } from "lucide-react"

export default function HomePage() {
  const { user, accounts, selectedHomeAccountId, theme } = useAccounts()

  const selectedAccount = accounts.find((account) => account.id === selectedHomeAccountId)

  if (!user) {
    return (
      <PublicLayout>
        <Header />
        <div className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] px-4 pt-16">
          <div className="max-w-6xl w-full">
            <section className="text-center mb-16">
              <h1 className="text-5xl font-bold mb-6" style={{ color: theme.colors.primary }}>
                Welcome to Central Livingston Banking
              </h1>
              <p className="text-xl mb-8" style={{ color: theme.colors.text }}>
                Your trusted partner for secure, innovative, and personalized banking solutions.
              </p>
              <div className="space-x-4">
                <Link href="/signup">
                  <Button
                    className="px-8 py-3 text-lg"
                    style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
                  >
                    Open an Account
                  </Button>
                </Link>
                <Link href="/login">
                  <Button
                    className="px-8 py-3 text-lg"
                    variant="outline"
                    style={{ borderColor: theme.colors.primary, color: theme.colors.primary }}
                  >
                    Log In
                  </Button>
                </Link>
              </div>
            </section>

            <section className="mb-16">
              <h2 className="text-3xl font-bold mb-8 text-center" style={{ color: theme.colors.secondary }}>
                Why Choose Central Livingston Banking?
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  {
                    title: "Security First",
                    icon: Shield,
                    description: "State-of-the-art encryption and fraud protection",
                  },
                  { title: "Mobile Banking", icon: Smartphone, description: "Manage your finances anytime, anywhere" },
                  {
                    title: "Financial Growth",
                    icon: TrendingUp,
                    description: "Competitive rates and investment options",
                  },
                  { title: "Personal Service", icon: Users, description: "Dedicated support team for all your needs" },
                  {
                    title: "Flexible Products",
                    icon: Banknote,
                    description: "Tailored accounts and loans for every stage of life",
                  },
                  { title: "24/7 Access", icon: Clock, description: "Round-the-clock online and phone banking" },
                ].map((feature) => (
                  <Card key={feature.title} style={{ backgroundColor: theme.colors.surface }}>
                    <CardHeader>
                      <feature.icon className="w-8 h-8 mb-2" style={{ color: theme.colors.primary }} />
                      <CardTitle style={{ color: theme.colors.text }}>{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p style={{ color: theme.colors.textSecondary }}>{feature.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </section>

            <section className="text-center mb-16">
              <h2 className="text-3xl font-bold mb-6" style={{ color: theme.colors.secondary }}>
                Join Thousands of Satisfied Customers
              </h2>
              <p className="text-xl mb-8" style={{ color: theme.colors.text }}>
                Experience the Central Livingston difference today. Our commitment to excellence and customer
                satisfaction sets us apart.
              </p>
              <Link href="/signup">
                <Button
                  className="px-8 py-3 text-lg"
                  style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
                >
                  Get Started Now
                </Button>
              </Link>
            </section>

            <section className="text-center">
              <h2 className="text-3xl font-bold mb-6" style={{ color: theme.colors.secondary }}>
                Have Questions?
              </h2>
              <p className="text-xl mb-8" style={{ color: theme.colors.text }}>
                Our team is here to help. Contact us for more information about our services.
              </p>
              <Link href="/contact">
                <Button
                  className="px-8 py-3 text-lg"
                  variant="outline"
                  style={{ borderColor: theme.colors.primary, color: theme.colors.primary }}
                >
                  Contact Us
                </Button>
              </Link>
            </section>
          </div>
        </div>
      </PublicLayout>
    )
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h1 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Welcome, {user.name}
        </h1>
        {selectedAccount ? (
          <Card style={{ backgroundColor: theme.colors.surface, color: theme.colors.text }}>
            <CardHeader>
              <CardTitle style={{ color: theme.colors.text }}>Featured Account</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg mb-2" style={{ color: theme.colors.textSecondary }}>
                Account Name: {selectedAccount.name}
              </p>
              <p className="text-lg mb-2" style={{ color: theme.colors.textSecondary }}>
                Account Number: {selectedAccount.accountNumber}
              </p>
              <p className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
                Balance: £{selectedAccount.balance.toFixed(2)}
              </p>
            </CardContent>
          </Card>
        ) : (
          <p style={{ color: theme.colors.textSecondary }}>No account selected to display on the home page.</p>
        )}
        <Link href="/accounts">
          <Button style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}>View All Accounts</Button>
        </Link>
      </div>
    </Layout>
  )
}

