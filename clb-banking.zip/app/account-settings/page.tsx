"use client"

import { useState } from "react"
import Layout from "../../components/layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"
import { cardStyles, inputStyles, buttonStyles, selectStyles } from "../../styles/theme"

export default function AccountSettings() {
  const { user, accounts, updateUserDetails, updateAccountDetails, updateCardDetails, theme } = useAccounts()

  const [selectedAccountId, setSelectedAccountId] = useState("")
  const [name, setName] = useState(user?.name || "")
  const [email, setEmail] = useState(user?.email || "")
  const [phoneNumber, setPhoneNumber] = useState(user?.phoneNumber || "")
  const [address, setAddress] = useState(user?.address || "")
  const [accountName, setAccountName] = useState("")
  const [cardNumber, setCardNumber] = useState("")
  const [expiryDate, setExpiryDate] = useState("")
  const [cvv, setCvv] = useState("")

  const handleUpdateUserDetails = (e: React.FormEvent) => {
    e.preventDefault()
    if (user) {
      updateUserDetails(user.id, { name, email, phoneNumber, address })
      toast({
        title: "User details updated",
        description: "Your personal information has been updated successfully.",
      })
    }
  }

  const handleUpdateAccountDetails = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedAccountId) {
      updateAccountDetails(selectedAccountId, { name: accountName })
      toast({
        title: "Account details updated",
        description: "The account name has been updated successfully.",
      })
    }
  }

  const handleUpdateCardDetails = (e: React.FormEvent) => {
    e.preventDefault()
    if (selectedAccountId) {
      updateCardDetails(selectedAccountId, { cardNumber, expiryDate, cvv })
      toast({
        title: "Card details updated",
        description: "The card details have been updated successfully.",
      })
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Account Settings
        </h2>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Personal Information</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateUserDetails} className="space-y-4">
              <Input
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="tel"
                placeholder="Phone Number"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="text"
                placeholder="Address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Update Personal Information
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Account Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateAccountDetails} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="text"
                placeholder="Account Name"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Update Account Details
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Card Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateCardDetails} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="text"
                placeholder="Card Number"
                value={cardNumber}
                onChange={(e) => setCardNumber(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="text"
                placeholder="Expiry Date (MM/YY)"
                value={expiryDate}
                onChange={(e) => setExpiryDate(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="text"
                placeholder="CVV"
                value={cvv}
                onChange={(e) => setCvv(e.target.value)}
                className={`${inputStyles} rounded-lg border-none`}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full rounded-lg`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Update Card Details
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

