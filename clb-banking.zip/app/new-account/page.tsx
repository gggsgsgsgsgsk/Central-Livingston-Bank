"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useAccounts } from "../../contexts/AccountContext"
import { cardStyles, inputStyles, buttonStyles } from "../../styles/theme"
import { toast } from "@/components/ui/use-toast"

export default function NewAccount() {
  const [accountName, setAccountName] = useState("")
  const { addAccount, theme } = useAccounts()
  const router = useRouter()

  const handleCreateAccount = (e: React.FormEvent) => {
    e.preventDefault()
    if (accountName.trim()) {
      addAccount(accountName.trim())
      toast({
        title: "Account created",
        description: `New account "${accountName}" has been created successfully.`,
      })
      router.push("/accounts")
    } else {
      toast({
        title: "Invalid input",
        description: "Please enter a valid account name.",
        variant: "destructive",
      })
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Create New Account
        </h2>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.secondary }}>Account Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleCreateAccount} className="space-y-4">
              <Input
                type="text"
                placeholder="Account Name"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                className={inputStyles}
                style={{ backgroundColor: theme.colors.background, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Create Account
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

