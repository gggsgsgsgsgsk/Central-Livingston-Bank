"use client"

import Layout from "../../components/layout"
import { Card, CardContent } from "@/components/ui/card"
import { useAccounts } from "../../contexts/AccountContext"
import { cardStyles } from "../../styles/theme"
import { ArrowUpRight, ArrowDownLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Transactions() {
  const { transactions, accounts, theme } = useAccounts()

  const getAccountName = (accountId: string) => {
    const account = accounts.find((a) => a.id === accountId)
    return account ? account.name : "Unknown Account"
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
            Transactions
          </h2>
          <Link href="/transactions/new">
            <Button
              className={`${cardStyles} px-4 py-2`}
              style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
            >
              New Transaction
            </Button>
          </Link>
        </div>
        {transactions.map((transaction) => (
          <Card key={transaction.id} className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
            <CardContent className="flex items-center justify-between p-4">
              <div className="flex items-center">
                {transaction.type === "credit" ? (
                  <ArrowDownLeft className="w-8 h-8 mr-3" style={{ color: theme.colors.secondary }} />
                ) : (
                  <ArrowUpRight className="w-8 h-8 mr-3" style={{ color: theme.colors.error }} />
                )}
                <div>
                  <p className="font-medium" style={{ color: theme.colors.text }}>
                    {transaction.description}
                  </p>
                  <p className="text-sm" style={{ color: theme.colors.textSecondary }}>
                    {new Date(transaction.date).toLocaleDateString()} - {getAccountName(transaction.accountId)}
                  </p>
                  <p className="text-sm" style={{ color: theme.colors.textSecondary }}>
                    {transaction.category}
                  </p>
                </div>
              </div>
              <p
                className="font-bold"
                style={{ color: transaction.type === "credit" ? theme.colors.secondary : theme.colors.error }}
              >
                {transaction.type === "credit" ? "+" : "-"}£{transaction.amount.toFixed(2)}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </Layout>
  )
}

