import { AccountProvider } from "../contexts/AccountContext"
import { Toaster } from "@/components/ui/toaster"
import AuthWrapper from "../components/auth-wrapper"

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AccountProvider>
          <AuthWrapper>{children}</AuthWrapper>
          <Toaster />
        </AccountProvider>
      </body>
    </html>
  )
}



import './globals.css'