"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { useAccounts } from "../../contexts/AccountContext"
import { toast } from "@/components/ui/use-toast"
import { type ThemeColor, cardStyles, inputStyles, buttonStyles, selectStyles } from "../../styles/theme"

export default function Settings() {
  const { accounts, themeColor, setThemeColor, isDarkMode, toggleDarkMode, theme, setSecretPageEnabled } = useAccounts()
  const router = useRouter()

  const handleThemeChange = (value: ThemeColor) => {
    setThemeColor(value)
    if (value === "cool") {
      setSecretPageEnabled(true)
      router.push("/secret-page")
    }
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.text }}>
          Settings
        </h2>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Theme Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span style={{ color: theme.colors.text }}>Dark Mode</span>
              <Switch checked={isDarkMode} onCheckedChange={toggleDarkMode} />
            </div>
            <div>
              <label className="block mb-2" style={{ color: theme.colors.text }}>
                Theme Color
              </label>
              <Select value={themeColor} onValueChange={handleThemeChange}>
                <SelectTrigger
                  className={`${inputStyles} ${selectStyles} rounded-lg border-none`}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select theme color" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="purple">Purple</SelectItem>
                  <SelectItem value="blue">Blue</SelectItem>
                  <SelectItem value="green">Green</SelectItem>
                  <SelectItem value="orange">Orange</SelectItem>
                  <SelectItem value="slate">Slate</SelectItem>
                  <SelectItem value="teal">Teal</SelectItem>
                  <SelectItem value="indigo">Indigo</SelectItem>
                  <SelectItem value="rose">Rose</SelectItem>
                  <SelectItem value="cool">Cool</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Notification Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span style={{ color: theme.colors.text }}>Push Notifications</span>
              <Switch />
            </div>
            <div className="flex justify-between items-center">
              <span style={{ color: theme.colors.text }}>Email Notifications</span>
              <Switch />
            </div>
          </CardContent>
        </Card>

        <Card
          className={cardStyles}
          style={{ backgroundColor: theme.colors.surface, boxShadow: "none", border: "none" }}
        >
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Security Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span style={{ color: theme.colors.text }}>Two-Factor Authentication</span>
              <Switch />
            </div>
            <Button
              className={`${buttonStyles} rounded-lg`}
              style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
            >
              Change Password
            </Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

