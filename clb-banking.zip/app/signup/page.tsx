"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import PublicLayout from "../../components/public-layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { cardStyles, inputStyles, buttonStyles } from "../../styles/theme"
import { toast } from "@/components/ui/use-toast"
import Link from "next/link"

export default function SignUp() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const { signUp, theme } = useAccounts()
  const router = useRouter()

  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault()
    try {
      signUp(email, password, name)
      toast({
        title: "Account created",
        description: "Your account has been created successfully.",
      })
      router.push("/dashboard")
    } catch (error) {
      toast({
        title: "Sign Up Error",
        description: "An error occurred while creating your account.",
        variant: "destructive",
      })
    }
  }

  return (
    <PublicLayout>
      <div className="flex justify-center items-center min-h-screen">
        <Card className={`${cardStyles} w-full max-w-md`} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle className="text-2xl font-bold" style={{ color: theme.colors.primary }}>
              Sign Up
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignUp} className="space-y-4">
              <Input
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={`${buttonStyles} w-full`}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Sign Up
              </Button>
            </form>
            <p className="mt-4 text-center" style={{ color: theme.colors.text }}>
              Already have an account?{" "}
              <Link href="/login" className="font-bold" style={{ color: theme.colors.primary }}>
                Log In
              </Link>
            </p>
          </CardContent>
        </Card>
      </div>
    </PublicLayout>
  )
}

