"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cardStyles, buttonStyles } from "../../styles/theme"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function AdminDashboard() {
  const { adminUser, isAdmin, accounts, theme } = useAccounts()
  const router = useRouter()

  useEffect(() => {
    if (!isAdmin) {
      router.push("/login")
    }
  }, [isAdmin, router])

  if (!isAdmin) return null

  const totalAccounts = accounts.length
  const totalBalance = accounts.reduce((sum, account) => sum + account.balance, 0)

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
            Admin Dashboard
          </h2>
          <Button
            onClick={() => router.push("/")}
            className={buttonStyles}
            style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
          >
            <ArrowLeft className="mr-2" /> Back to Home
          </Button>
        </div>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Bank Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <p style={{ color: theme.colors.text }}>Total Accounts: {totalAccounts}</p>
            <p style={{ color: theme.colors.text }}>Total Balance: £{totalBalance.toFixed(2)}</p>
          </CardContent>
        </Card>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>All Accounts</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {accounts.map((account) => (
                <li key={account.id} className="flex justify-between items-center">
                  <span style={{ color: theme.colors.text }}>{account.name}</span>
                  <span style={{ color: theme.colors.primaryLight }}>£{account.balance.toFixed(2)}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <div className="flex space-x-4">
          <Link href="/admin/create-account" className="flex-1">
            <Button
              className={`${buttonStyles} w-full`}
              style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
            >
              Create New Account
            </Button>
          </Link>
          <Link href="/admin/transactions" className="flex-1">
            <Button
              className={`${buttonStyles} w-full`}
              style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
            >
              View All Transactions
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  )
}

