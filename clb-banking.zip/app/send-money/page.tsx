"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useAccounts } from "../../contexts/AccountContext"
import { toast } from "@/components/ui/use-toast"
import { cardStyles, inputStyles, buttonStyles } from "../../styles/theme"

export default function SendMoney() {
  const [amount, setAmount] = useState("")
  const [recipient, setRecipient] = useState("")
  const [selectedAccountId, setSelectedAccountId] = useState("")
  const { accounts, addTransaction, theme } = useAccounts()
  const router = useRouter()

  const handleSendMoney = (e: React.FormEvent) => {
    e.preventDefault()
    const parsedAmount = Number.parseFloat(amount)
    if (isNaN(parsedAmount) || parsedAmount <= 0 || !selectedAccountId || !recipient) {
      toast({
        title: "Invalid input",
        description: "Please fill in all fields with valid values.",
        variant: "destructive",
      })
      return
    }
    addTransaction({
      accountId: selectedAccountId,
      type: "debit",
      amount: parsedAmount,
      description: `Sent to ${recipient}`,
      date: new Date().toISOString(),
      category: "Transfer",
    })
    toast({
      title: "Money sent",
      description: `£${parsedAmount.toFixed(2)} has been sent to ${recipient}.`,
    })
    router.push("/")
  }

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Send Money
        </h2>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.secondary }}>Transfer Details</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSendMoney} className="space-y-4">
              <Select onValueChange={setSelectedAccountId} value={selectedAccountId}>
                <SelectTrigger
                  className={inputStyles}
                  style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
                >
                  <SelectValue placeholder="Select account" />
                </SelectTrigger>
                <SelectContent>
                  {accounts.map((account) => (
                    <SelectItem key={account.id} value={account.id}>
                      {account.name} (£{account.balance.toFixed(2)})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="text"
                placeholder="Recipient"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Input
                type="number"
                placeholder="Amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                step="0.01"
                min="0"
                className={inputStyles}
                style={{ backgroundColor: theme.colors.surfaceLight, color: theme.colors.text }}
              />
              <Button
                type="submit"
                className={buttonStyles}
                style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
              >
                Send Money
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  )
}

