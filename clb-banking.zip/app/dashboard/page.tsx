"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import Layout from "../../components/layout"
import { useAccounts } from "../../contexts/AccountContext"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cardStyles, buttonStyles } from "../../styles/theme"
import Link from "next/link"

export default function Dashboard() {
  const { user, accounts, theme, isDemoUser, demoAccountName } = useAccounts()
  const router = useRouter()

  useEffect(() => {
    if (!user) {
      router.push("/login")
    }
  }, [user, router])

  if (!user) return null

  const displayName = isDemoUser ? demoAccountName : user.name

  return (
    <Layout>
      <div className="space-y-6">
        <h2 className="text-3xl font-bold" style={{ color: theme.colors.primary }}>
          Welcome, {displayName}
        </h2>
        <Card className={cardStyles} style={{ backgroundColor: theme.colors.surface }}>
          <CardHeader>
            <CardTitle style={{ color: theme.colors.text }}>Your Accounts</CardTitle>
          </CardHeader>
          <CardContent>
            {accounts.length === 0 ? (
              <p style={{ color: theme.colors.textSecondary }}>You don't have any accounts yet.</p>
            ) : (
              <ul className="space-y-2">
                {accounts.map((account) => (
                  <li key={account.id} className="flex justify-between items-center">
                    <span style={{ color: theme.colors.text }}>{account.name}</span>
                    <span style={{ color: theme.colors.primaryLight }}>£{account.balance.toFixed(2)}</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
        <div className="flex space-x-4">
          <Link href="/accounts" className="flex-1">
            <Button
              className={`${buttonStyles} w-full`}
              style={{ backgroundColor: theme.colors.primary, color: theme.colors.text }}
            >
              View All Accounts
            </Button>
          </Link>
          <Link href="/new-account" className="flex-1">
            <Button
              className={`${buttonStyles} w-full`}
              style={{ backgroundColor: theme.colors.secondary, color: theme.colors.text }}
            >
              Create New Account
            </Button>
          </Link>
        </div>
      </div>
    </Layout>
  )
}

